USE [master]

GO

IF DB_ID('Apartment') IS NOT NULL
	DROP DATABASE Apartment

GO
	
CREATE DATABASE Apartment

GO

USE Apartment

GO

CREATE TABLE Country 
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] varchar(256) not null,
	[IsEnabled] bit not null
)
GO

TRUNCATE TABLE Country
INSERT INTO Country
SELECT 'India',1

GO


CREATE TABLE [State] 
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[CountryId] Int not null,
	[Name] varchar(256) not null,
	[IsEnabled] bit not null
)
GO

TRUNCATE TABLE [State]
INSERT INTO [State]
SELECT 1, 'Maharashtra',1
GO

CREATE TABLE City 
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[StateId] Int not null,
	[Name] varchar(256) not null,
	[IsEnabled] bit not null
)

GO

TRUNCATE TABLE City
INSERT INTO City
SELECT 1, 'Pune',1

GO

CREATE TABLE [Role]
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] varchar(256) not null,
	[IsEnabled] bit not null
)
GO

TRUNCATE TABLE [Role]
INSERT INTO [Role]
SELECT 'Forum Read',1
UNION SELECT 'Froum Write', 1
UNION SELECT 'Poll Read', 1
UNION SELECT 'Poll Write', 1
UNION SELECT 'Notice Read', 1
UNION SELECT 'Notice Write', 1
UNION SELECT 'Service Request Read', 1
UNION SELECT 'Service Request Write', 1
UNION SELECT 'Gallory Read', 1
UNION SELECT 'Gallory Write', 1

GO


CREATE TABLE [UserType]
(
	[Id] smallint IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] varchar(256) not null,
	[IsEnabled] bit not null
)

GO

TRUNCATE TABLE [UserType]
INSERT INTO [UserType]
SELECT 'Admin', 1
UNION SELECT 'Chairman', 1
UNION SELECT 'Secretory', 1
UNION SELECT 'Member', 1
UNION SELECT 'Vendor', 1
GO


CREATE TABLE Relation
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] varchar(256) not null,
	[IsActive] bit not null
)
GO

TRUNCATE TABLE Relation
GO
INSERT INTO Relation
SELECT 'Self', 1
UNION SELECT 'Wife', 1
UNION SELECT 'Son', 1
UNION SELECT 'Doughter', 1
UNION SELECT 'GrandFather', 1
UNION SELECT 'GrandMonther', 1
UNION SELECT 'Brother', 1
UNION SELECT 'Friend', 1

GO



CREATE TABLE [dbo].[Society]
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] varchar(256) not null ,
	[Address1] varchar(256) not null ,
	[Address2] varchar(256) null,
	[CityId] int not null,
	[Mobile] smallint not null,
	[Phone] smallint null,
	[Email] varchar(64) not null,  --- ApartmentFacebook will provide email.
	[Website] varchar(255) null,
	[IsActive] bit not null
)

GO
--ALTER TABLE [Member] ALTER COLUMN [UserTypeId] smallint not null
CREATE TABLE [Member]
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[SocietyId] Int not null,
	[Email] varchar(64) null,
	[Password] varchar(64) not null,
	[UserTypeId] smallint, --- 1 = Onwer 2 = Tenant
	[RoleId] int, -- 1 = Admin, 2 = Chairman, 3= Secretory, 4 = members and so on 
	[JoinDate] smalldatetime not null,
	[InterCom] int, 
	[IsStayingHere] bit not null,
	[IsActive] bit not null
)

GO

CREATE TABLE [MemberInformation]
(
	[Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[MemberId] Int not null,
	[RelationId] Int Not null,
	[Name] varchar(256) not null,
	[DOB] smalldatetime null,
	[BadgeNumber] int, --- Should get generate automatically serial number for a society
	[Wing] varchar(256) not null,
	[FlatNumber] smallint not null,
	[Mobile] smallint not null,
	[Phone] smallint null,
	[Email] varchar(64) null,
	[Photo] varchar(256) null,
	[IsActive] bit not null
)


GO

